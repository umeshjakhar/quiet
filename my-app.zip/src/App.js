import React, { Component } from 'react';
import logo from './logo.svg';
import './App.css';

class App extends Component {
  constructor(){
	  super();	  
	  //this.otpToTone = this.otpToTone.bind(this);
	  
  }
  
  // otpToTone(e){
	  // e.preventDefault();
	  
	  
	  // const data = new FormData();
	  // data['otp'] = e.target['otp'].value;
	  // console.log(data);
  // }
  
  
  render() {
    return (
      <div className="App">
      </div>
    );
  }
}

export default App;
